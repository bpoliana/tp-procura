# procura
TP1 - Laboratório de Engenharia de Software

/proc - é onde se encontram os arquivos referentes à aplicação (app) do procura
  admin.py - onde registra os models da app
  apps.py - apps do sistema
  models.py - todos os modelos do banco, incluindo todas as classes necessarias
  urls.py - endereçamento da app
  tests.py - arquivo de testes
  views.py - visualização dos models 
