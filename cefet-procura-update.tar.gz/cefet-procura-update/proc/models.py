import datetime

from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone



class HealthCenter(models.Model):
	name = models.CharField(max_length=60)
	center_type = models.CharField(max_length=15)
	cnpj = models.CharField(max_length=15)

	def __str__(self):
		return self.nome

class n_UserManager(models.Manager):

	def search(self, query):
			return self.get_queryset().filter(
					name__icontains=query, email__icontains=query
					)

class n_User(models.Model):
	dj_user = models.OneToOneField(User, on_delete=models.CASCADE)
	name = models.CharField(max_length=100)
	email = models.EmailField(max_length=100)
	password = models.CharField(max_length=20)
	#type = models.CharField()

	objects = n_UserManager()

	def __str__(self):
		return self.dj_user.nome

class Doctor(models.Model):
	crm = models.AutoField(primary_key = True, default = True)
	name = models.CharField(max_length=60)
	data = models.DateField(default = True)

	def __str__(self):
		return self.name

class Patient(models.Model):
	name = models.CharField(max_length=60)
	cpf = models.CharField(max_length=30)

	def __str__(self):
		return self.name

class Medicine(models.Model):
    medicamento_id = models.AutoField(primary_key = True)
    medicamento_data = models.DateField()
    medicamento_nome = models.CharField(max_length= 45)
    medicamento_dosagem = models.CharField(max_length= 45)
    medicamento_fabricante = models.CharField(max_length= 45)
    medicamento_quantidade = models.DecimalField(max_digits =5,decimal_places=0)

	#def __str__(self):
		#return self.medicamento_nome


