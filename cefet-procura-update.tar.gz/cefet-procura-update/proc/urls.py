from django.conf.urls import include, url
from django.views.generic import RedirectView
from django.contrib.auth import *
from .  import views


app_name = 'proc'
urlpatterns = [
	url(r'^$', RedirectView.as_view(url='home', permanent=True)),
    url(r'^register/$', views.register, name='register'),
    url(r'^sucess/$', views.register_sucessed, name="sucsess"),
    url(r'^home/$', views.home, name="home"),
    url(r'^login/$', views.home, name="login"),
	url(r'^logout/$', views.register, name="logout"),
	url(r'^medicine/$',views.medicine_manager, name= "medicine_manager"),
	url(r'^medicineregister/$',views.medicine_register, name= "medicineregister"),
	url(r'^medicine_registered/$',views.medicine_show, name="medicine_registered"),
	url(r'^medicine_delete/(?P<id>\d+)/$',views.medicine_delete, name = "medicine_delete"),
	url(r'^medicineupdate/(?P<id>\d+)/$',views.medicine_update, name= "medicineupdate"),
	#url(r'^medicine_registered/$', MedicineList.as_view()),
	#url(r'^medicineregister/$',MedicineCreate.as_view())

	url(r'^doctor/$',views.doctor_manager, name= "doctor_manager"),
	url(r'^doctorregister/$',views.doctor_register, name= "doctorregister"),
	url(r'^doctor_registered/$',views.doctor_show, name="doctor_registered"),
	url(r'^doctor_delete/(?P<id>\d+)/$',views.doctor_delete, name = "doctor_delete"),
	url(r'^doctorupdate/(?P<id>\d+)/$',views.doctor_update, name= "doctorupdate")

]
