import django_tables2 as tables
from .models import Medicine
from .models import Doctor

class MedicineTable(tables.Table):
	class Meta:
		model = Medicine

class DoctorTable(tables.Table):
            class Meta:
                         model = Doctor