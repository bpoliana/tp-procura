from django.contrib import admin
from .models import HealthCenter, n_User,Medicine, Doctor


#class UsersAdmin(admin.ModelAdmin):
		#pass
#admin.site.register(n_User, UsersAdmin)
admin.site.register(n_User)
#class HealthCentersAdmin(admin.ModelAdmin):
#	model = HealthCenter
#	list_display = ['name', 'center_type']
admin.site.register(HealthCenter)
#admin.site.register(HealthCenter, HealthCentersAdmin)
admin.site.register(Medicine)
admin.site.register(Doctor)
# Register your models here.
