import datetime

from django import forms
from django.contrib.auth.models import User
from django.forms import ModelForm

from .models import n_User
from .models import Medicine
from .models import Doctor

class RegistrationForm(forms.Form):

	#cpf_regex = '^[0-9{3}\.[0-9]{3}\.[0-9]{3}-[0-9]{2}$'
	cpf_regex = '^[0-9]{11}$'
	cpf_error_msg = 'Esse cpf e invalido.'

	name = forms.CharField(label='Nome', max_length=100, required=True)
	cpf = forms.RegexField(label = 'CPF:', regex=cpf_regex, max_length=14, min_length=11, required = True)
#	user_type = forms.CharField(label='Voce e Paciente, Medico, Gerente de Centros de Saude ou Fornecedor?', max_length=20, required=True)

	email = forms.EmailField(label='Email:', required=True)
	password = forms.CharField(label= 'Senha:', widget=forms.PasswordInput(), required=True)
	conf_password = forms.CharField(label= 'Confirme sua senha:', widget=forms.PasswordInput(), required=True)

	date_cadastro = datetime.date.today()


class RegistrationFormMedicine(forms.Form):
	#class Meta:
		#model = Medicine
		#fields = ['medicamento_id','medicamento_nome','medicamento_data','medicamento_dosagem','medicamento_fabricante','medicamento_quantidade']
	medicamento_nome = forms.CharField(label='Nome', max_length=45, required=True)
	medicamento_data = forms.DateField(label = 'Data', required = True)
	medicamento_dosagem = forms.CharField(label='Dosagem',max_length=45, required=True)
	medicamento_fabricante = forms.CharField(label='Fabricante',max_length=45,required=True)
	medicamento_quantidade = forms.DecimalField(label='Quantidade', max_digits=5,decimal_places=0,required=True)

class RegistrationFormDoctor(forms.Form):
	name = forms.CharField(label='Nome', max_length=45, required=True)
	crm = forms.CharField(label = 'CRM', max_length=30, required = True)
	data = forms.DateField(label = 'Data', required = True)

