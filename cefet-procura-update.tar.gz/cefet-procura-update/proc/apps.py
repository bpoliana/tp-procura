from django.apps import AppConfig


class ProcConfig(AppConfig):
    name = 'proc'
