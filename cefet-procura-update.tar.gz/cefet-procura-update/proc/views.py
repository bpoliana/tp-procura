from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout, login, authenticate
from django.contrib.auth.forms import *
from django.views.decorators.csrf import csrf_protect
from django.shortcuts import render_to_response, render, redirect
from django.http import HttpResponseRedirect
from django.template import RequestContext
from django.urls import reverse
from .models import HealthCenter, n_User, Medicine, Doctor
from .forms import *
from .tables import *
from django.views.generic import CreateView,ListView,DeleteView,UpdateView
from django.core.urlresolvers import reverse_lazy
import pdb



def health_centers(request):
	h = HealthCenter.objects.filter(type='Saude mental')
	#return render(request, 'proc/health_centers.html', {'list1': list1})
	return render(request, 'proc/health_centers.html', {'h': h})

def doctors(request):
	return render(request)

def register(request):
	print(request.method)
	if request.method == 'POST':
		form = RegistrationForm(request.POST)
		if form.is_valid():
			user = User.objects.create_user(username=form.cleaned_data['name'], password=form.cleaned_data['password'],email=form.cleaned_data['email'])
			return render(request, 'proc/success.html', {'form': form })

	else:
		form = RegistrationForm()
	#variables = RequestContext(request, {'form': form})

	return render(request, 'proc/register.html', {'form': form })

def register_sucessed(request):
	return render_to_response('proc/success.html',)

def logout_page(request):
	logout(request)
	return HttpResponseRedirect('/') #logout redireciona para pagina inicial

#@login_required(login_url='/login')
def home(request):
	return render_to_response('proc/index.html', {} )

def login_user(request):
	return render_to_response('registration/login.html', {} )

def medicine_manager(request):
	return render_to_response('proc/main_medicine.html',{})

def medicine_register(request):
	print(request.method)
	if request.method == 'POST':
		form = RegistrationFormMedicine(request.POST)
		if form.is_valid():

			med = Medicine()
			med.medicamento_nome = form.cleaned_data['medicamento_nome']
			med.medicamento_data = form.cleaned_data['medicamento_data']
			med.medicamento_dosagem = form.cleaned_data['medicamento_dosagem']
			med.medicamento_fabricante = form.cleaned_data['medicamento_fabricante']
			med.medicamento_quantidade = form.cleaned_data['medicamento_quantidade']

			med.save()
			#return render(request,'proc/success.html',{'form':form})
			return HttpResponseRedirect('')
	else:
		form = RegistrationFormMedicine()

	return render(request, 'proc/medicineregister.html', {'form':form})

def medicine_show(request):
    queryset = Medicine.objects.all()
    #table = MedicineTable(queryset)
    return render(request,"proc/medicine_registered.html", {'queryset': queryset})

def medicine_delete(request,id):
	med = Medicine.objects.get(pk = id)
	med.delete()
	#Medicine.objects.filter(medicamento_id=id).delete()
	return HttpResponseRedirect('/proc/medicine_registered')

def medicine_update(request,id):
	#pdb.set_trace()
	med = Medicine.objects.get(pk = id)

	if request.method == 'POST':
		form = RegistrationFormMedicine(request.POST)
		if form.is_valid(): #request.POST.get('medicamento_nome')
			#pdb.set_trace()
			med.medicamento_nome = form.cleaned_data['medicamento_nome']
			med.medicamento_data = form.cleaned_data['medicamento_data']
			med.medicamento_dosagem = form.cleaned_data['medicamento_dosagem']
			med.medicamento_fabricante = form.cleaned_data['medicamento_fabricante']
			med.medicamento_quantidade = form.cleaned_data['medicamento_quantidade']
			med.save()
			return HttpResponseRedirect('/proc/medicine_registered')

	else:
		form = RegistrationFormMedicine()
		#form.medicamento_nome = med.medicamento_nome
		#form.medicamento_data = med.medicamento_data
		#form.medicamento_dosagem= med.medicamento_dosagem
		#form.medicamento_fabricante = med.medicamento_fabricante
		#form.medicamento_quantidade = med.medicamento_quantidade
	return render(request, 'proc/medicineupdate.html', {'form':form ,'id': id,'med':med})






	#########





def doctor_manager(request):
	return render_to_response('proc/main_doctor.html',{})

def doctor_register(request):
	print(request.method)
	if request.method == 'POST':
		form = RegistrationFormDoctor(request.POST)
		if form.is_valid():

			doc = Doctor()
			doc.name = form.cleaned_data['name']
			doc.crm = form.cleaned_data['crm']

			doc.save()
			#return render(request,'proc/success.html',{'form':form})
			return HttpResponseRedirect('')
	else:
		form = RegistrationFormDoctor()

	return render(request, 'proc/doctorregister.html', {'form':form})

def doctor_show(request):
    queryset = Doctor.objects.all()
    #table = DoctorTable(queryset)
    return render(request,"proc/doctor_registered.html", {'queryset': queryset})

def doctor_delete(request,id):
	doc = Doctor.objects.get(pk = id)
	doc.delete()
	#Doctor.objects.filter(crm=id).delete()
	return HttpResponseRedirect('/proc/doctor_registered')

def doctor_update(request,id):
	#pdb.set_trace()
	doc = Doctor.objects.get(pk = id)

	if request.method == 'POST':
		form = RegistrationFormDoctor(request.POST)
		if form.is_valid(): #request.POST.get('name')
			#pdb.set_trace()
			doc.name = form.cleaned_data['name']
			doc.crm = form.cleaned_data['crm']

			doc.save()
			return HttpResponseRedirect('/proc/doctor_registered')

	else:
		form = RegistrationFormDoctor()
		#form.medicamento_nome = med.medicamento_nome
		#form.medicamento_data = med.medicamento_data
		#form.medicamento_dosagem= med.medicamento_dosagem
		#form.medicamento_fabricante = med.medicamento_fabricante
		#form.medicamento_quantidade = med.medicamento_quantidade
	return render(request, 'proc/doctorupdate.html', {'form':form ,'id': id,'doc':doc})

